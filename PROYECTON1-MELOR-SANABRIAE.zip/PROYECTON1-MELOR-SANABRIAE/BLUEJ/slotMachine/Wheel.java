import java.util.ArrayList;
import java.util.List;

/**
 * Representa una rueda de la máquina tragamonedas.
 * Organiza una lista de símbolos que se repite y muestra cada símbolo uno después de otro, como una cadena.
 * 
 * @author Juan José Sanabria Espinel y Tomas Alejandro Melo Rangel
 * @version 1.0
 */
public class Wheel {
    private List<Symbol> symbols;
    private int xPosition;
    private int yPosition;
    private boolean isVisible;
    private Rectangle fondo;

    /**
     * Constructor para inicializar una rueda vacía en una posición específica.
     * 
     * @param x Coordenada X inicial de la rueda en el lienzo.
     * @param y Coordenada Y inicial de la rueda en el lienzo.
     */
    public Wheel(int x, int y) {
        this.symbols = new ArrayList<>();
        this.xPosition = x;
        this.yPosition = y;
        this.isVisible = false;
        
        // Creamos la columna visual blanca
        this.fondo = new Rectangle();
        this.fondo.changeSize(280, 50); // Alto, Ancho
        this.fondo.changeColor("white");
        this.fondo.moveHorizontal(x - 70); // Ajuste desde la posición original de Rectangle
        this.fondo.moveVertical(y - 15);
    }

    /**
     * Ajusta la posición solicitada por el usuario a un índice válido.
     * 
     * @param pos Posición solicitada (empezando en 1).
     * @return Índice ajustado de 0 al tamaño de la lista.
     */
    private int adjustPosition(int pos) {
        if (pos < 1) return 0;
        if (pos > symbols.size()) return symbols.size();
        return pos - 1;
    }

    /**
     * Agrega un símbolo garantizando que su color no exista antes.
     * 
     * @param pos Posición donde se desea insertar (1 a N).
     * @param color Color del nuevo símbolo a agregar.
     * @return true si se agregó correctamente, false si el color ya existía.
     */
    public boolean addSymbol(int pos, String color) {
        for (Symbol s : symbols) {
            if (s.getColor().equalsIgnoreCase(color)) return false;
        }
        Symbol newSymbol = new Symbol(color);
        symbols.add(adjustPosition(pos), newSymbol);
        updateVisuals();
        return true;
    }

    /**
     * Elimina el símbolo que coincida con el color especificado.
     * 
     * @param color Color del símbolo a quitar.
     * @return true si se encontró y eliminó, false en caso contrario.
     */
    public boolean delSymbol(String color) {
        for (int i = 0; i < symbols.size(); i++) {
            if (symbols.get(i).getColor().equalsIgnoreCase(color)) {
                symbols.remove(i).makeInvisible();
                updateVisuals();
                return true;
            }
        }
        return false;
    }

    /**
     * Gira la rueda desplazando el último símbolo a la primera posición visible.
     */
    public void spin() {
        if (symbols.isEmpty()) return;
        symbols.add(0, symbols.remove(symbols.size() - 1));
        updateVisuals();
    }

    /**
     * Gira la rueda internamente hasta que el color deseado quede visible arriba.
     * 
     * @param color Color objetivo a poner.
     * @return true si el símbolo existe y se ubicó, false si no existe.
     */
    public boolean placeSymbol(String color) {
        boolean exists = symbols.stream().anyMatch(s -> s.getColor().equalsIgnoreCase(color));
        if (!exists) return false;
        
        while (!getVisibleColor().equalsIgnoreCase(color)) {
            spin();
        }
        return true;
    }

    /**
     * Obtiene el color del símbolo que se encuentra en la posición superior.
     * 
     * @return Color visible, o cadena vacía si no hay símbolos.
     */
    public String getVisibleColor() {
        if (symbols.isEmpty()) return "";
        return symbols.get(0).getColor();
    }

    /**
     * Obtiene un arreglo con los colores de todos los símbolos en la rueda.
     * 
     * @return Arreglo de cadenas ordenado de arriba hacia abajo.
     */
    public String[] getSymbols() {
        String[] colors = new String[symbols.size()];
        for (int i = 0; i < symbols.size(); i++) {
            colors[i] = symbols.get(i).getColor();
        }
        return colors;
    }

    /**
     * Actualiza como se ven los símbolos en la pantalla.
     */
    private void updateVisuals() {
        int currentY = this.yPosition + 10; // Margen superior para los símbolos
        for (Symbol s : symbols) {
            s.setPosition(this.xPosition + 10, currentY); // Centrar el círculo en la rueda
            if (this.isVisible) s.makeVisible();
            currentY += 40;
        }
    }

    /**
     * Despliega la rueda en pantalla.
     */
    public void makeVisible() {
        this.isVisible = true;
        this.fondo.makeVisible(); // Mostramos la columna blanca
        updateVisuals();
    }

    /**
     * Oculta la rueda de la pantalla.
     */
    public void makeInvisible() {
        this.isVisible = false;
        this.fondo.makeInvisible(); 
        for (Symbol s : symbols) {
            s.makeInvisible();
        }
    }
}