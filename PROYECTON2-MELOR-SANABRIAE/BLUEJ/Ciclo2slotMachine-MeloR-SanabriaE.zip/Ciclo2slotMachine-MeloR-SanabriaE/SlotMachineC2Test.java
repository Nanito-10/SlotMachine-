import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Pruebas de unidad para el ciclo 2 de SlotMachine:
 * swap, lock/unlock, spin(wheel,steps) y spin(setSymbols).
 * @author Juan José Sanabria Espinel y Tomas Alejandro Melo Rangel
 * @version 1.0
 */
public class SlotMachineC2Test {

    private SlotMachine machine;

    /**
     * Se ejecuta antes de cada prueba: crea una máquina nueva y vacía.
     * Nunca se llama makeVisible(), por lo que todas las pruebas corren
     * en modo invisible.
     */
    @BeforeEach
    public void setUp() {
        machine = new SlotMachine();
    }

    // swap(wheel1, wheel2)

    /**
     * Qué debería hacer: intercambiar el contenido de dos ruedas
     * sin importar que tengan distinta cantidad de símbolos.
     */
    @Test
    public void shouldSwapTwoWheelsRegardlessOfSymbolCount() {
        machine.addWheel(1);           // rueda 1
        machine.addWheel(2);           // rueda 2
        machine.addSymbol(1, "red");
        machine.addSymbol(1, "blue");  // rueda 1 tiene 2 símbolos: [blue, red]
        machine.addSymbol(2, "green"); // rueda 2 tiene 1 símbolo: [green]

        machine.swap(1, 2);

        assertTrue(machine.ok());
        // Después del swap, lo que se ve en la rueda 1 debe ser lo que antes
        // se veía en la rueda 2, y viceversa.
        assertArrayEquals(new String[]{"green"}, machine.symbols());
    }

    /**
     * Qué NO debería hacer: intercambiar ruedas si hay menos de dos
     * ruedas en la máquina (no hay con qué intercambiar).
     */
    @Test
    public void shouldNotSwapWhenLessThanTwoWheelsExist() {
        machine.addWheel(1); // solo una rueda

        machine.swap(1, 2);

        assertFalse(machine.ok());
    }

    /**
     * Qué debería hacer: si se piden posiciones fuera de rango, ajustarlas
     * al máximo/mínimo válido.
     */
    @Test
    public void shouldClampOutOfRangeSwapPositions() {
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");

        machine.swap(1, 100); // 100 se ajusta a la última rueda (2)

        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"blue"}, machine.symbols());
    }

    /**
     * Qué debería hacer: prevenir el giro de una rueda fija incluso usando
     * spin(wheel) de UN solo argumento (sin steps), no solo la variante
     * spin(wheel, steps). Este caso existe porque encontramos que lock()
     * no estaba siendo respetado por esta sobrecarga en particular.
     */
    @Test
    public void shouldPreventSingleArgSpinOnLockedWheel() {
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.addSymbol(1, "blue");
        machine.placeSymbol(1, "red"); // estado conocido

        machine.lock(1);
        machine.spin(1); // spin(wheel) de un solo argumento

        assertFalse(machine.ok());
        assertEquals("red", machine.configuration()[0]); // no debió moverse
    }

    // lock(wheel) / unlock(wheel)

    /**
     * Qué debería hacer: una rueda bloqueada no debe moverse cuando
     * se le pide girar explícitamente.
     */
    @Test
    public void shouldPreventSpinOnLockedWheel() {
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.addSymbol(1, "blue");
        String visibleBefore = machine.symbols()[0]; // color visible inicial

        machine.lock(1);
        machine.spin(1, 2);

        assertFalse(machine.ok());
        assertEquals(visibleBefore, machine.configuration()[0]); // no se movió
    }

    /**
     * Qué debería hacer: tras un unlock, la rueda debe volver a girar
     * con normalidad.
     */
    @Test
    public void shouldAllowSpinAfterUnlock() {
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.addSymbol(1, "blue");

        machine.lock(1);
        machine.unlock(1);
        machine.spin(1, 1);

        assertTrue(machine.ok());
    }

    /**
     * Qué NO debería hacer: fijar una rueda si la máquina no tiene ninguna.
     */
    @Test
    public void shouldNotLockWhenNoWheelsExist() {
        machine.lock(1);

        assertFalse(machine.ok());
    }

    // spin(wheel, steps)


    /**
     * Qué debería hacer: girar la rueda indicada  "steps" veces.
     * Con 3 símbolos y 3 pasos, la rueda vuelve a mostrar el mismo color
     * inicial osea (dio una vuelta completa) 
     */
    @Test
    public void shouldSpinWheelExactStepsGiven() {
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.addSymbol(1, "blue");
        machine.addSymbol(1, "green");
        String visibleBefore = machine.configuration()[0];

        machine.spin(1, 3); // vuelta completa con 3 símbolos

        assertTrue(machine.ok());
        assertEquals(visibleBefore, machine.configuration()[0]);
    }

    /**
     * Qué NO debería hacer: girar una rueda si la máquina está vacía.
     */
    @Test
    public void shouldNotSpinWheelWhenMachineIsEmpty() {
        machine.spin(1, 3);

        assertFalse(machine.ok());
    }

    // spin() global — debe saltar ruedas bloqueadas

    /**
     * Qué debería hacer: mover las ruedas libres y dejar intacta
     * la rueda bloqueada.
     */
    @Test
    public void shouldSkipLockedWheelsOnGlobalSpin() {
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol(1, "red");
        machine.addSymbol(1, "blue");
        machine.addSymbol(2, "green");
        machine.addSymbol(2, "yellow");

        String lockedWheelColorBefore = machine.configuration()[0];
        machine.lock(1);
        machine.spin(); // gira todas las no bloqueadas

        assertTrue(machine.ok());
        assertEquals(lockedWheelColorBefore, machine.configuration()[0]); // rueda 1 no se movió
    }

    /**
     * Qué NO debería hacer: girar si todas las ruedas están bloqueadas
     * (no hay ninguna libre para mover).
     */
    @Test
    public void shouldNotSpinWhenAllWheelsAreLocked() {
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.addSymbol(1, "blue");

        machine.lock(1);
        machine.spin();

        assertFalse(machine.ok());
    }

    // spin(setSymbols) 

    /**
     * Qué debería hacer: dejar la máquina exactamente en los colores
     * pedidos, cuando todos existen en sus respectivas ruedas.
     */
    @Test
    public void shouldSetExactConfigurationWhenAllColorsExist() {
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol(1, "red");
        machine.addSymbol(1, "blue");
        machine.addSymbol(2, "green");
        machine.addSymbol(2, "yellow");

        machine.spin(new String[]{"blue", "yellow"});

        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"blue", "yellow"}, machine.configuration());
    }

    /**
     * Qué NO debería hacer: aplicar ningún cambio si uno de los colores
     * pedidos no existe en su rueda (todo o nada).
     */
    @Test
    public void shouldNotChangeAnyWheelWhenOneColorDoesNotExist() {
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "green");

        String[] before = machine.configuration();
        machine.spin(new String[]{"red", "purple"}); // "purple" no existe en la rueda 2

        assertFalse(machine.ok());
        assertArrayEquals(before, machine.configuration()); // nada se movió
    }

    /**
     * Qué NO debería hacer: mover ninguna rueda si una está bloqueada
     * y su color objetivo no coincide con el que ya muestra.
     */
    @Test
    public void shouldNotChangeAnyWheelWhenLockedWheelCannotReachTarget() {
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol(1, "red");
        machine.addSymbol(1, "blue");
        machine.addSymbol(2, "green");
        machine.addSymbol(2, "yellow");

        machine.placeSymbol(1, "red");   // fijamos lo qué se ve en la rueda 1
        machine.placeSymbol(2, "green"); // la de la rueda 2

        String[] before = machine.configuration();
        machine.lock(1); // rueda 1 fija mostrando "red"
        machine.spin(new String[]{"blue", "yellow"}); // pide cambiar la rueda bloqueada

        assertFalse(machine.ok());
        assertArrayEquals(before, machine.configuration()); // ni siquiera la rueda 2 se movió
    }

    /**
     * Qué NO debería hacer: aceptar un arreglo de colores cuyo tamaño
     * no coincide con el número de ruedas.
     */
    @Test
    public void shouldNotAcceptSymbolArrayWithWrongLength() {
        machine.addWheel(1);
        machine.addSymbol(1, "red");

        machine.spin(new String[]{"red", "blue"}); // 2 colores, 1 rueda

        assertFalse(machine.ok());
    }
}