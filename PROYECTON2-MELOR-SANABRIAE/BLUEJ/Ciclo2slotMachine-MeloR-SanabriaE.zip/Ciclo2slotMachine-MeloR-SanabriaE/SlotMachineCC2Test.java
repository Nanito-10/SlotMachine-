import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * Juan José Sanabria Espinel y Tomas Alejandro Melo Rangel
 * Prefijo asignado: MrSe (Melo-Rangel, Sanabria-Espinel; orden alfabético por primer apellido)
 */
public class SlotMachineCC2Test {

    // swap(wheel1, wheel2) 

    /**
     * Debería: al intercambiar dos ruedas, la que queda en la posición 1
     * debe mostrar lo que antes mostraba la que estaba en la posición 2,
     * sin importar cuántos símbolos tenga cada una.
     */
    @Test
    public void accordingMrSeShouldSwapWheelsRegardlessOfSymbolCount() {
        SlotMachine machine = new SlotMachine();
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol(1, "red");
        machine.addSymbol(1, "blue");
        machine.addSymbol(2, "green");

        machine.swap(1, 2);

        assertTrue(machine.ok());
        // La rueda 1 ahora debe mostrar lo que antes mostraba la rueda 2.
        assertEquals("green", machine.configuration()[0]);
    }

    /**
     * No debería: hacer swap si la máquina tiene menos de dos ruedas
     * (no hay con qué intercambiar).
     */
    @Test
    public void accordingMrSeShouldRejectSwapWhenFewerThanTwoWheelsExist() {
        SlotMachine machine = new SlotMachine();
        machine.addWheel(1); // solo una rueda

        machine.swap(1, 2);

        assertFalse(machine.ok());
    }

    // spin(setSymbols)

    /**
     * No debería: aplicar ningún cambio si uno de los colores pedidos
     * no existe en su rueda correspondiente (comportamiento todo o nada).
     */
    @Test
    public void accordingMrSeShouldRejectSpinSetSymbolsWhenColorMissing() {
        SlotMachine machine = new SlotMachine();
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "green");

        String[] before = machine.configuration();
        machine.spin(new String[]{"red", "purple"}); // "purple" no existe

        assertFalse(machine.ok());
        assertArrayEquals(before, machine.configuration()); // nada se movió
    }

    // lock(wheel) / unlock(wheel) 

    /**
     * Debería: una rueda fijada (lock) no debe moverse ante un intento de
     * giro, y debe volver a poder girar después de un unlock.
     */
    @Test
    public void accordingMrSeShouldKeepLockedWheelFixedAndAllowSpinAfterUnlock() {
        SlotMachine machine = new SlotMachine();
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.addSymbol(1, "blue");
        machine.placeSymbol(1, "red"); // estado conocido, sin asumir orden de addSymbol

        machine.lock(1);
        machine.spin(1, 2); // intenta girar la rueda fija

        assertFalse(machine.ok());
        assertEquals("red", machine.configuration()[0]); // no debió moverse

        machine.unlock(1);
        machine.spin(1, 1); // ahora sí debe poder girar

        assertTrue(machine.ok());
    }

    // spin(wheel, steps) 

    /**
     * Debería: si una rueda tiene N símbolos distintos y se gira exactamente
     * N pasos, debe volver a mostrar el mismo color visible inicial (dio
     * una vuelta completa). Esta propiedad es válida sin importar el orden
     * interno con el que cada equipo haya guardado los símbolos.
     */
    @Test
    public void accordingMrSeShouldReturnToSameVisibleColorAfterFullRotation() {
        SlotMachine machine = new SlotMachine();
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.addSymbol(1, "blue");
        machine.addSymbol(1, "green");
        String before = machine.configuration()[0]; // no asumimos cuál es, solo lo guardamos

        machine.spin(1, 3); // vuelta completa: 3 símbolos, 3 pasos

        assertTrue(machine.ok());
        assertEquals(before, machine.configuration()[0]);
    }
}
